local AceOO = AceLibrary("AceOO-2.0")
local NoHighlightingFrameClass = AceOO.Class(GridFrame.frameClass)

local _frameClass = nil
if ( not _frameClass ) then
	_frameClass = GridFrame.frameClass
	GridFrame.frameClass = NoHighlightingFrameClass 
end

function NoHighlightingFrameClass .prototype:CreateFrames()
    NoHighlightingFrameClass .super.prototype.CreateFrames(self)
	
    self.frame:SetHighlightTexture(nil)
end