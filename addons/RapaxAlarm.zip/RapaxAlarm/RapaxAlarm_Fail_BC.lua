--####################################################################################
--#################################www.rapax-guild.com################################
--####################################################################################
--####################################+###############################################
--##################################### #######+ #####################################
--#####################################' ,####  +#####################################
--################################+,      :##`     +:+################################
--#################+###########          ,         `;    ###########+#################
--###########+#'  '##,  .'#####',`        +         +,: ######:`:`,##;  ##############
--###########    ;            ;####       :#        ,####+`      #    ;   `###########
--#########          +###+         ,#      #      .#; ;`      :+###,        `#########
--#######,        ###########.             `#          #: .##########:        '#######
--######       #####;;;';;;'''##.           ##         +###;';;';;';#####      `######
--#####         ;+###';';';;;';########.     ##: ########';;';;;;;''####,       `#####
--####   .##:      `'############# `'         ##`     +############;  '###;'#+`  `####
--### '####          ,'#####+''########,      `##########,'######;.     '#` `####,,###
--########                    ###+:` :`         `##,:'####  :###;         ##  ########
--#######                   .##:      ;#         ,##+   +##   ####;         ## #######
--######`                 .####        '#         +####  ####  ####.          +'######
--#####+      `################'######;.#+      .;######'###############+`      ######
--#####            +####,   ;##############################`   ;######          ,#####
--###`#          .###       ##############################++      `###,       ,  #:###
--### ' #,      :####:       ##.  .##################` +####+    `;######;    '; ;.###
--###   #; #   `###########;        :##############`     .##############+##'# +#  .###
--###` `#+:#`  ######:     `;###.     :##########+     ,###;#### `;#####,  ;#`##. '###
--#### .####+  ############,       ,     ######`##: ,`      ,###########+  #####, ####
--####:;#####  ####+,` .:'#####,          ;##'    +#    :####';:##+'##### ,#####.+####
--###########+ #########+:                 ##      ,#        `;########## ######+#####
--############+#################:          ##         #;#################:############
--#################'               `      ###;     ,`   #           ##################
--###################+ :.               :######`               :. ####################
--#########################.      `## :##########. #'       :#########################
--####################################################################################
--########################':##########.         `+##########,#########################
--########################'     :#                   :#.     #########################
--#########################     :    +   ##  ##   #    .     #########################
--#########################,    ##+ ##+;########+##' ##'    '#########################
--##########################    ########################   .##########################
--###########################   ########################  .###########################
--############################',########################`+############################
--##############################+##################+#####+############################
--################' ##; #######` ######`,##: #####+ ,######; +##### '#################
--################' ### ######:.: #####.,### ##### # +#######. ## .+##################
--################; ` +######' ;,`.####    :+#### #`+ #########  #####################
--################: #; ###### #### ;### ,####### :###` ######: ## :###################
--################; ### ,### +####' ### ,######`.##### ,###+ +####; +#################
--#################+'####++#######';;;''';###+########''::::,######;,,;###############
--############################## ###################### ##############################
--#############################` .#######+ ## ##'##+##  .#############################
--#############################   '               `  .   #############################
--##############################     ,+##########'.     ##############################
--#########################:.+############################+`+#########################
--#########################      '#####:`      `;#####:      #########################
--#########################       ;                 `+       #########################
--#########################                                 ,#########################
--#########################;  ;                          `  ##########################
--########################## `#;  +,  ;.         .  ',  '#  ##########################
--########################## ###  ##  ##   ##   #' `##  ###,##########################
--##############################  ### ##` ###; ,## ###  ##############################
--##############################, ######` #### ,#####' '##############################
--############################### '##### ###### #####, ###############################
--################################`################## ################################
--####################################################################################
--####################################################################################

RapaxAlarm.SpellID["30844"] = {
	--desc = "Proximity Bomb (Shadowmoon Technician - Blood Furnace)";
	sound = 3;
	
};

RapaxAlarm.SpellID["32786"] = {
	--desc = "Proximity Bomb (Shadowmoon Technician - Blood Furnace Heroic)";
	sound = 3;
	
};

RapaxAlarm.SpellID["29973"] = {
	--desc = "Arcane Explosion (Shade of Aran - Karazhan)";
	sound = 3;
	
};

RapaxAlarm.SpellID["30131"] = {
	--desc = "Cleave (Nightbane - Karazhan)";
	sound = 3;
	tankSound = 0;
	
};

RapaxAlarm.SpellID["30210"] = {
	--desc = "Smoldering Breath (Nightbane - Karazhan)";
	sound = 3;
	tankSound = 0;
	applicationOnly = true;
	
};

RapaxAlarm.SpellID["25653"] = {
	--desc = "Tail Sweep (Nightbane - Karazhan)";
	sound = 3;
	applicationOnly = true;
	
};

RapaxAlarm.SpellID["30852"] = {
	--desc = "Shadow Nova (Prince Malchezaar - Karazhan)";
	sound = 3;
	tankSound = 0;
	
};

RapaxAlarm.SpellID["33132"] = {
	--desc = "Fire Nova (Mennu the Betrayer - Slave Pens)";
	sound = 3;
	
};

RapaxAlarm.SpellID["34268"] = {
	--desc = "Acid Breath (Ghaz'an - The Underbog)";
	sound = 3;
	tankSound = 0;
	applicationOnly = true;
	
};

RapaxAlarm.SpellID["34267"] = {
	--desc = "Tail Sweep (Ghaz'an - The Underbog)";
	sound = 3;
};

RapaxAlarm.SpellID["38737"] = {
	--desc = "Tail Sweep (Ghaz'an - The Underbog Heroic)";
	sound = 3;
};

RapaxAlarm.SpellID["38197"] = {
	--desc = "Arcane Explosion (Talon King Ikiss - Sethekk Halls)";
	sound = 3;
	
};

RapaxAlarm.SpellID["40425"] = {
	--desc = "Arcane Explosion (Talon King Ikiss - Sethekk Halls - Heroic)";
	sound = 3;
	
};

RapaxAlarm.SpellID["34268"] = {
	--desc = "Corrosive Acid (Ambassador Hellmaw - Shadow Labyrinth)";
	sound = 3;
	tankSound = 0;
	applicationOnly = true;
	
};

RapaxAlarm.SpellID["35311"] = {
	--desc = "Stream of Machine Fluid (Gatewatchers - Mechanar)";
	sound = 3;
	tankSound = 0;
	applicationOnly = true;
	
};

RapaxAlarm.SpellID["34168"] = {
	--desc = "Spore Cloud (Hungarfen - Underbog)";
	sound = 3;
	
	applicationOnly = true;
};

RapaxAlarm.SpellID["31914"] = {
	--desc = "Sand Breath (Epoch Hunter - CoT:OHF)";
	sound = 3;
	tankSound = 0;
	
};

RapaxAlarm.SpellID["31473"] = {
	--desc = "Sand Breath (Aeonus - CoT:BM)";
	sound = 3;
	tankSound = 0;
	
};

RapaxAlarm.SpellID["39049"] = {
	--desc = "Sand Breath (Aeonus - CoT:BM - Heroic)";
	sound = 3;
	tankSound = 0;
	
};

RapaxAlarm.SpellID["31436"] = {
	--desc = "Malevolent Cleave (Kaz'rogal - CoT:HS)";
	sound = 3;
	tankSound = 0;
	
};

RapaxAlarm.SpellID["31345"] = {
	--desc = "Cleave (Azgalor - CoT:HS)";
	sound = 3;
	tankSound = 0;
	
};

RapaxAlarm.SpellID["40599"] = {
	--desc = "Arcing Smash (Gurtogg Bloodboil - Black Temple)";
	sound = 3;
	tankSound = 0;
	
};

RapaxAlarm.SpellID["40599"] = {
	--desc = "Saber Lash (Mother Shahraz - Black Temple)";
	sound = 3;
	tankSound = 0;
	
};

RapaxAlarm.SpellID["37433"] = {
	--desc = "Spout (Lurker - SSC)";
	sound = 3;
	tankSound = 0;
};

RapaxAlarm.SpellID["33666"] = {
	--desc = "Sonic Boom (Murmur - Shadow Labyrinth)";
	sound = 3;
	applicationOnly = true;
	
};

RapaxAlarm.SpellID["38795"] = {
	--desc = "Sonic Boom (Murmur - Shadow Labyrinth Heroic)";
	sound = 3;
	applicationOnly = true;
	
};

RapaxAlarm.SpellID["35152"] = {
	--desc = "Nether Detonation (Mechano-Lord Capacitus - Mechanar)";
	sound = 3;
	
};

RapaxAlarm.SpellID["30619"] = {
	--desc = "Cleave (Magtheridon)";
	sound = 3;
	tankSound = 0;
	
};

RapaxAlarm.SpellID["33813"] = {
	--desc = "Hurtful Strike (Gruul)";
	sound = 3;
	tankSound = 0;
	trivialLevel = 85;
};

RapaxAlarm.SpellID["33671"] = {
	--desc = "Shatter (Gruul)";
	sound = 3;
	
};

RapaxAlarm.SpellID["39174"] = {
	--desc = "Cleave (Lair Brute - Gruul's Lair)";
	sound = 3;
	tankSound = 0;
	
};

RapaxAlarm.SpellID["39174"] = {
	--desc = "Arcing Smash (High King Maulgar - Gruul's Lair)";
	sound = 3;
	tankSound = 0;
	
};

RapaxAlarm.SpellID["29832"] = {
	--desc = "Shadow Cleave (Attumen the Huntsman - Karazhan)";
	sound = 3;
	tankSound = 0;
	
};

RapaxAlarm.SpellID["31043"] = {
	--desc = "Tinhead (Attumen the Huntsman - Karazhan)";
	sound = 3;
	tankSound = 0;
	
};

RapaxAlarm.SpellID["29949"] = {
	--desc = "Explosion (Flame Wreath) (Shade of Aran - Karazhan)";
	sound = 3;
};

