--####################################################################################
--#################################www.rapax-guild.com################################
--####################################################################################
--####################################+###############################################
--##################################### #######+ #####################################
--#####################################' ,####  +#####################################
--################################+,      :##`     +:+################################
--#################+###########          ,         `;    ###########+#################
--###########+#'  '##,  .'#####',`        +         +,: ######:`:`,##;  ##############
--###########    ;            ;####       :#        ,####+`      #    ;   `###########
--#########          +###+         ,#      #      .#; ;`      :+###,        `#########
--#######,        ###########.             `#          #: .##########:        '#######
--######       #####;;;';;;'''##.           ##         +###;';;';;';#####      `######
--#####         ;+###';';';;;';########.     ##: ########';;';;;;;''####,       `#####
--####   .##:      `'############# `'         ##`     +############;  '###;'#+`  `####
--### '####          ,'#####+''########,      `##########,'######;.     '#` `####,,###
--########                    ###+:` :`         `##,:'####  :###;         ##  ########
--#######                   .##:      ;#         ,##+   +##   ####;         ## #######
--######`                 .####        '#         +####  ####  ####.          +'######
--#####+      `################'######;.#+      .;######'###############+`      ######
--#####            +####,   ;##############################`   ;######          ,#####
--###`#          .###       ##############################++      `###,       ,  #:###
--### ' #,      :####:       ##.  .##################` +####+    `;######;    '; ;.###
--###   #; #   `###########;        :##############`     .##############+##'# +#  .###
--###` `#+:#`  ######:     `;###.     :##########+     ,###;#### `;#####,  ;#`##. '###
--#### .####+  ############,       ,     ######`##: ,`      ,###########+  #####, ####
--####:;#####  ####+,` .:'#####,          ;##'    +#    :####';:##+'##### ,#####.+####
--###########+ #########+:                 ##      ,#        `;########## ######+#####
--############+#################:          ##         #;#################:############
--#################'               `      ###;     ,`   #           ##################
--###################+ :.               :######`               :. ####################
--#########################.      `## :##########. #'       :#########################
--####################################################################################
--########################':##########.         `+##########,#########################
--########################'     :#                   :#.     #########################
--#########################     :    +   ##  ##   #    .     #########################
--#########################,    ##+ ##+;########+##' ##'    '#########################
--##########################    ########################   .##########################
--###########################   ########################  .###########################
--############################',########################`+############################
--##############################+##################+#####+############################
--################' ##; #######` ######`,##: #####+ ,######; +##### '#################
--################' ### ######:.: #####.,### ##### # +#######. ## .+##################
--################; ` +######' ;,`.####    :+#### #`+ #########  #####################
--################: #; ###### #### ;### ,####### :###` ######: ## :###################
--################; ### ,### +####' ### ,######`.##### ,###+ +####; +#################
--#################+'####++#######';;;''';###+########''::::,######;,,;###############
--############################## ###################### ##############################
--#############################` .#######+ ## ##'##+##  .#############################
--#############################   '               `  .   #############################
--##############################     ,+##########'.     ##############################
--#########################:.+############################+`+#########################
--#########################      '#####:`      `;#####:      #########################
--#########################       ;                 `+       #########################
--#########################                                 ,#########################
--#########################;  ;                          `  ##########################
--########################## `#;  +,  ;.         .  ',  '#  ##########################
--########################## ###  ##  ##   ##   #' `##  ###,##########################
--##############################  ### ##` ###; ,## ###  ##############################
--##############################, ######` #### ,#####' '##############################
--############################### '##### ###### #####, ###############################
--################################`################## ################################
--####################################################################################
--####################################################################################

local test = false
local vcnt = 0
local tout = 0
local user = {}
local utime = 0

---------------------------------------
--- Helper Functions ------------------
---------------------------------------

local function AddMsg(msg)
	DEFAULT_CHAT_FRAME:AddMessage(msg)
end

---------------------------------------

local function SaveAllNames()
	local num,i,name
	user = {}

	num = GetNumRaidMembers()
	if (num>0) then
		for i = 1, num do
			name = UnitName("raid" .. i)
			tinsert(user,name)
		end
		return
	end
	
	num = GetNumPartyMembers()
	if (num>0) then
		name = UnitName("player")
		tinsert(user,name)
		for i = 1, num do
			name = UnitName("party" .. i)
			tinsert(user,name)
		end
		return
	end
end

---------------------------------------

local function RemoveName(name)
	local i
	for i = #user, 1, -1 do
		if (user[i] == name) then
			tremove(user,i)
			return true
		end
	end
	return false
end

---------------------------------------
--- Main Functions --------------------
---------------------------------------

function RapaxAlarm_Init()
	AddMsg(RAPAXALARM_GREETING)

	SLASH_RAPAXALARM1 = "/rapaxalarm"
	SLASH_RAPAXALARM2 = "/rapax"
	SlashCmdList["RAPAXALARM"] = RapaxAlarm_SlashHandler
end

---------------------------------------

--add new localization here
		local b = false
		local s = false
function RapaxAlarm_SlashHandler(msg)
	if (msg=="") then
		AddMsg(RAPAXALARM_HELP1)
		AddMsg(RAPAXALARM_HELP2)
		AddMsg(RAPAXALARM_HELP3)
	--	AddMsg(RAPAXALARM_HELP4)
		AddMsg(RAPAXALARM_HELP5)
		AddMsg(RAPAXALARM_SYERIS)
	end
--add on and off commands here

if (msg=="sound") then
  InterfaceOptionsFrame_OpenToFrame(getglobal("RapaxAlarm_MainFrame"))
  end
  
 -- if (msg=="cthun") then
 -- PlaySoundFile("Sound\\Creature\\CThun\\CThunYouWillDie.Wav")
 -- end


		if (msg=="syeris") then
		PlaySoundFile("Sound\\Character\\Dwarf\\DwarfMale\\DwarfMaleLaugh01.wav")

    if s then
		s = false
		AddMsg(RAPAXALARM_SYERISOFF)
    else
        s = true
		AddMsg(RAPAXALARM_SYERISON)
    end
	end
	
		if (msg=="magtheridon") then
    if b then
		b = false
		AddMsg(RAPAXALARM_MAGOFF)
    else
        b = true
		AddMsg(RAPAXALARM_MAGON)
    end
	end
	
	
	if (msg=="test") then
    if test then
		test = false
		AddMsg(RAPAXALARM_TESTOFF)
    else
        test = true
		AddMsg(RAPAXALARM_TESTON)
    end
	end

	if (msg=="version check") then
		vcnt = 0
		tout = 4
		SaveAllNames()
		AddMsg(RAPAXALARM_VERCHECK)
		SendAddonMessage("RapaxAlarm","VC","RAID")
	end
end

---------------------------------------

function RapaxAlarm_Msg(msg,sender)
	local prefix  = strsub(msg,1,2)
	local message = strsub(msg,3)
	
	if (prefix=="VC") then
		SendAddonMessage("RapaxAlarm","VB" .. RAPAXALARM_VER,"RAID")
	end

	if (prefix=="VA" or prefix=="VB") then --VA for version 1.4 and older
		if (tout>0) then
			if (RemoveName(sender)) then
				vcnt = vcnt + 1
				AddMsg(vcnt .. ": " .. sender .. " v" .. message)
			end
		end
	end
end

---------------------------------------

function RapaxAlarm_Update(sec)

	utime = utime + sec
	if (utime<0.15) then
		return
	end
--add local false command here--
	local a = false
	local i
	for i = 1,8 do
		local name = GetPlayerBuffName(GetPlayerBuff(i,"HARMFUL"))

		if (name~=nil) then
if (strfind(name,BLIZZARDDEBUFF)~=nil) then 		
		a = true
			end
if (strfind(name,CAVEINDEBUFF)~=nil) then
		a = true
			end
if (strfind(name,DEBRISDEBUFF)~=nil) then
		a = true
			end
if (strfind(name,SPOREDEBUFF)~=nil) then
		a = true
			end
if (strfind(name,ASTRODEBUFF)~=nil) then
		a = true
			end
if (strfind(name,MOLTENDEBUFF)~=nil) then
		a = true
			end
if (strfind(name,CHARREDDEBUFF)~=nil) then
		a = true
			end

			if (test) then
				a = true
			end

		end
	end
	
--add the frame toggle here--

	if (s) then
		if not (RapaxAlarmSyeris:IsVisible()) then
			RapaxAlarmSyeris:Show()
		end
	else
		if (RapaxAlarmSyeris:IsVisible()) then
			RapaxAlarmSyeris:Hide()
		end
	end
	
	if (a) then
		if not (RapaxAlarmMain:IsVisible()) then
			RapaxAlarmMain:Show()
		end
	else
		if (RapaxAlarmMain:IsVisible()) then
			RapaxAlarmMain:Hide()
		end
	end
	
	if (b) then
		if not (RapaxAlarmMagtheridon:IsVisible()) then
			RapaxAlarmMagtheridon:Show()
		end
	else
		if (RapaxAlarmMagtheridon:IsVisible()) then
			RapaxAlarmMagtheridon:Hide()
		end
	end

	if (tout>0) then
		tout = tout - utime
		if (tout<=0) and (#user>0) then
			AddMsg(RAPAXALARM_NORA)
			for i = 1,#user do
				AddMsg(i .. ": " .. user[i])
			end
		end
	end

	utime = 0
end

