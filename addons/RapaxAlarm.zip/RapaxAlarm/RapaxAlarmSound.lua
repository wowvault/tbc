--####################################################################################
--#################################www.rapax-guild.com################################
--####################################################################################
--####################################+###############################################
--##################################### #######+ #####################################
--#####################################' ,####  +#####################################
--################################+,      :##`     +:+################################
--#################+###########          ,         `;    ###########+#################
--###########+#'  '##,  .'#####',`        +         +,: ######:`:`,##;  ##############
--###########    ;            ;####       :#        ,####+`      #    ;   `###########
--#########          +###+         ,#      #      .#; ;`      :+###,        `#########
--#######,        ###########.             `#          #: .##########:        '#######
--######       #####;;;';;;'''##.           ##         +###;';;';;';#####      `######
--#####         ;+###';';';;;';########.     ##: ########';;';;;;;''####,       `#####
--####   .##:      `'############# `'         ##`     +############;  '###;'#+`  `####
--### '####          ,'#####+''########,      `##########,'######;.     '#` `####,,###
--########                    ###+:` :`         `##,:'####  :###;         ##  ########
--#######                   .##:      ;#         ,##+   +##   ####;         ## #######
--######`                 .####        '#         +####  ####  ####.          +'######
--#####+      `################'######;.#+      .;######'###############+`      ######
--#####            +####,   ;##############################`   ;######          ,#####
--###`#          .###       ##############################++      `###,       ,  #:###
--### ' #,      :####:       ##.  .##################` +####+    `;######;    '; ;.###
--###   #; #   `###########;        :##############`     .##############+##'# +#  .###
--###` `#+:#`  ######:     `;###.     :##########+     ,###;#### `;#####,  ;#`##. '###
--#### .####+  ############,       ,     ######`##: ,`      ,###########+  #####, ####
--####:;#####  ####+,` .:'#####,          ;##'    +#    :####';:##+'##### ,#####.+####
--###########+ #########+:                 ##      ,#        `;########## ######+#####
--############+#################:          ##         #;#################:############
--#################'               `      ###;     ,`   #           ##################
--###################+ :.               :######`               :. ####################
--#########################.      `## :##########. #'       :#########################
--####################################################################################
--########################':##########.         `+##########,#########################
--########################'     :#                   :#.     #########################
--#########################     :    +   ##  ##   #    .     #########################
--#########################,    ##+ ##+;########+##' ##'    '#########################
--##########################    ########################   .##########################
--###########################   ########################  .###########################
--############################',########################`+############################
--##############################+##################+#####+############################
--################' ##; #######` ######`,##: #####+ ,######; +##### '#################
--################' ### ######:.: #####.,### ##### # +#######. ## .+##################
--################; ` +######' ;,`.####    :+#### #`+ #########  #####################
--################: #; ###### #### ;### ,####### :###` ######: ## :###################
--################; ### ,### +####' ### ,######`.##### ,###+ +####; +#################
--#################+'####++#######';;;''';###+########''::::,######;,,;###############
--############################## ###################### ##############################
--#############################` .#######+ ## ##'##+##  .#############################
--#############################   '               `  .   #############################
--##############################     ,+##########'.     ##############################
--#########################:.+############################+`+#########################
--#########################      '#####:`      `;#####:      #########################
--#########################       ;                 `+       #########################
--#########################                                 ,#########################
--#########################;  ;                          `  ##########################
--########################## `#;  +,  ;.         .  ',  '#  ##########################
--########################## ###  ##  ##   ##   #' `##  ###,##########################
--##############################  ### ##` ###; ,## ###  ##############################
--##############################, ######` #### ,#####' '##############################
--############################### '##### ###### #####, ###############################
--################################`################## ################################
--####################################################################################
--####################################################################################

RapaxAlarm = {
	Version = "1.1.0"; -- Version number (text format)
	VersionNumber = 10100; -- Numeric version number for checking out-of-date clients
	DataCode = "4"; -- Saved Variable versioning, change this value to force a reset to default
	DebugMode = nil; -- Turn on debug alerts
	TestMode = nil; -- Activate alerts for events marked as "test only"
	CanTank = nil; -- The active character is capable of tanking
	TankMode = nil; -- The active character is a tank
	SpellName = { }; -- List of spells (requires localization, spell IDs are preferred)
	SpellID = { }; -- List of spell IDs
	MobID = { }; -- List of mob IDs for melee attack detection
	UpdateFound = nil; -- Upgrade available?
	IgnoreTimeAmount = .2; -- Number of seconds between alert sounds
	IgnoreTime = nil;
	IgnoreUpdateTimeAmount = 5; -- Number of seconds between sending out version updates
	IgnoreUpdateTime = nil;
	IgnoreUpdateRequestTimeAmount = 90; -- Number of seconds between sending out version update requests
	IgnoreUpdateRequestTime = nil;
	Users = { };
	PartyMembers = 0;
	RaidMembers = 0;
	PowerAuras = nil;
	ShowAlert = nil;
	Volume = 3; -- Volume setting, 3 = default
};

RapaxAlarmData = {};

function RapaxAlarm_ChatPrint(str)
	DEFAULT_CHAT_FRAME:AddMessage("[RapaxAlarm] "..str, 0.25, 1.0, 0.25);
end

function RapaxAlarm_ErrorPrint(str)
	DEFAULT_CHAT_FRAME:AddMessage("[RapaxAlarm] "..str, 1.0, 0.5, 0.5);
end

function RapaxAlarm_DebugPrint(str)
	if (RapaxAlarm.DebugMode) then
		DEFAULT_CHAT_FRAME:AddMessage("[RapaxAlarm] "..str, 0.75, 1.0, 0.25);
	end
end

function RapaxAlarm_ScanPrint(str)
	if (RapaxAlarmData.ScanMode) then
		DEFAULT_CHAT_FRAME:AddMessage("[RapaxAlarm] "..str, 0.5, 0.5, 0.85);
	end
end

function RapaxAlarm_GetMobId(GUID)
    if not GUID then return end
    return tonumber(GUID:sub(-12, -7), 16)
end


function RapaxAlarm_OnEvent(self, event, ...)
	if (event == "VARIABLES_LOADED") then
		if (RapaxAlarmData.DataCode ~= RapaxAlarm.DataCode) then
			RapaxAlarmData.Active = true;
			RapaxAlarmData.Sounds = { };
			RapaxAlarmData.Sounds[1] = true;
			RapaxAlarmData.Sounds[2] = true;
			RapaxAlarmData.Sounds[3] = true;
			RapaxAlarmData.DataCode = RapaxAlarm.DataCode;
			RapaxAlarmData.Volume = RapaxAlarm.Volume;
			RapaxAlarmData.ScanMode = nil;		
			RapaxAlarm_ChatPrint(string.format(RapaxAlarmLocal.Loading_NewDatabase, RapaxAlarm.Version));
		end
		RapaxAlarm_RenderOptions();
		RapaxAlarm_Option_Active(RapaxAlarmData.Active);
		RapaxAlarm_Option_ScanMode(RapaxAlarmData.ScanMode);
		RapaxAlarm_Option_HighSound(RapaxAlarmData.Sounds[1]);
		RapaxAlarm_Option_LowSound(RapaxAlarmData.Sounds[2]);
		RapaxAlarm_Option_FailSound(RapaxAlarmData.Sounds[3]);
		RapaxAlarm_Option_Tank(RapaxAlarmData.TankMode);
		if (RapaxAlarmData.Volume) then
			RapaxAlarm.Volume = RapaxAlarmData.Volume;
		end
		return;
	end
	if (event == "COMBAT_LOG_EVENT_UNFILTERED") then
		local timestamp, eventType, sourceGUID, sourceName, sourceFlags, destGUID, destName, destFlags, misc1, misc2, misc3, misc4, misc5, misc6, misc7 = ...; 

		local SpellType = tostring(eventType);
		if (destGUID == UnitGUID("player")) then
			if (SpellType == "ENVIRONMENTAL_DAMAGE") then
				RapaxAlarm_ScanPrint(SpellType.." - "..misc1);
				if (misc1 ~= "FALLING") then
					RapaxAlarm_PlaySound(2);
					return;
				end
			elseif (SpellType=="SPELL_PERIODIC_DAMAGE" or SpellType=="SPELL_DAMAGE" or ((SpellType=="SPELL_AURA_APPLIED" or SpellType=="SPELL_AURA_APPLIED_DOSE") and misc4=="DEBUFF")) then
				local SpellID = tostring(misc1);
				local SpellName = tostring(misc2);
				local SpellSourceGUID = tostring(sourceGUID);
				RapaxAlarm_ScanPrint(SpellType.." - "..SpellID.." - "..SpellName.." - "..tostring(sourceName)..">"..tostring(destName));
				if (RapaxAlarm.SpellID[SpellID]) then
					RapaxAlarm_DebugPrint(SpellID.." - ID Match Found");
					if (RapaxAlarm.SpellID[SpellID].test and not RapaxAlarm.TestMode) then
						return;
					end
					if (SpellSourceGUID ~= UnitGUID("player") or not RapaxAlarm.SpellID[SpellID].ignoreSelfInflicted) then
						if ((not RapaxAlarm.SpellID[SpellID].applicationOnly) or (RapaxAlarm.SpellID[SpellID].applicationOnly and (SpellType == "SPELL_AURA_APPLIED" or SpellType == "SPELL_AURA_APPLIED_DOSE"))) then
							if (RapaxAlarm.SpellID[SpellID].tankSound and RapaxAlarm.TankMode) then
								RapaxAlarm_PlaySound(RapaxAlarm.SpellID[SpellID].tankSound);
							else
								RapaxAlarm_PlaySound(RapaxAlarm.SpellID[SpellID].sound);
							end
							--RapaxAlarm_DebugPrint(RapaxAlarm.SpellID[SpellID].desc);
							return;
						end
					end
				elseif (RapaxAlarm.SpellName[SpellName]) then
					if (RapaxAlarm.SpellName[SpellName].test and not RapaxAlarm.TestMode) then
						return;
					end
					if (SpellSourceGUID ~= UnitGUID("player") or not RapaxAlarm.SpellName[SpellName].ignoreSelfInflicted) then
						RapaxAlarm_DebugPrint(SpellName.." - Name Match Found");
						if ((not RapaxAlarm.SpellName[SpellName].applicationOnly) or (RapaxAlarm.SpellName[SpellName].applicationOnly and (SpellType == "SPELL_AURA_APPLIED" or SpellType == "SPELL_AURA_APPLIED_DOSE"))) then
							if (RapaxAlarm.SpellName[SpellName].tankSound and RapaxAlarm.TankMode) then
								RapaxAlarm_PlaySound(RapaxAlarm.SpellName[SpellName].tankSound);
							else
								RapaxAlarm_PlaySound(RapaxAlarm.SpellName[SpellName].sound);
							end
							--RapaxAlarm_DebugPrint(RapaxAlarm.SpellName[SpellName].desc);				
							return;
						end
					end
				end
			elseif (SpellType=="SWING_DAMAGE" or SpellType=="SWING_MISSED") then
				local SourceMobID = tostring(RapaxAlarm_GetMobId(sourceGUID));
				if (RapaxAlarm.MobID[SourceMobID]) then
					if (RapaxAlarm.MobID[SourceMobID].test and not RapaxAlarm.TestMode) then
						return;
					end
					if (SpellType=="SWING_DAMAGE") then
						local damage = misc1 ~= "ABSORB" and misc1 or 0
						if (damage > 0 or not RapaxAlarm.MobID[SourceMobID].damageOnly) then
							if (RapaxAlarm.MobID[SourceMobID].tankSound and RapaxAlarm.TankMode) then
								RapaxAlarm_PlaySound(RapaxAlarm.MobID[SourceMobID].tankSound);
							else
								RapaxAlarm_PlaySound(RapaxAlarm.MobID[SourceMobID].sound);
							end
							--RapaxAlarm_DebugPrint(RapaxAlarm.MobID[SourceMobID].desc);				
							return;						
						end
					elseif (not RapaxAlarm.MobID[SourceMobID].damageOnly and SpellType=="SWING_MISSED") then
						RapaxAlarm_PlaySound(RapaxAlarm.MobID[SourceMobID].sound);
						--RapaxAlarm_DebugPrint(RapaxAlarm.MobID[SourceMobID].desc);				
						return;						
					end
				end
				
			end
		end
		return;
	end
	if (event == "CHAT_MSG_ADDON") then
		local msgPrefix, msgMessage, msgType, msgSender = ...;
		if (msgPrefix == "RapaxAlarm_v") then
			if (not RapaxAlarm.Users[msgSender]) then
				RapaxAlarm_SendUpdate(msgType);
			end
			RapaxAlarm.Users[msgSender] = msgMessage;
			if ((tonumber(msgMessage) > RapaxAlarm.VersionNumber) and not RapaxAlarm.UpdateFound) then
				RapaxAlarm.UpdateFound = RapaxAlarm_ParseVersionNumber(msgMessage);
				RapaxAlarm_ChatPrint(string.format(RapaxAlarmLocal.Loading_OutOfDate, RapaxAlarm.UpdateFound));
			end
			return;
		end
		if (msgPrefix == "RapaxAlarm_u") then
			RapaxAlarm_DebugPrint(msgSender.." requested update to "..msgType);
			RapaxAlarm_SendUpdate(msgType);
			return;
		end
		if (msgPrefix == "RapaxAlarm") then
			
			RapaxAlarm_ChatPrint("MSG: " .. msgMessage)
		end
		return;
	end
	if (event == "PARTY_MEMBERS_CHANGED") then
		local PartyMembers = GetNumPartyMembers();
		if (PartyMembers > RapaxAlarm.PartyMembers and RapaxAlarm.RaidMembers == 0) then
			RapaxAlarm_SendUpdate("PARTY");
		end
		RapaxAlarm.PartyMembers = PartyMembers;
		return;
	end
	if (event == "RAID_ROSTER_UPDATE") then
		local RaidMembers = GetNumRaidMembers();		
		if (RaidMembers > RapaxAlarm.RaidMembers) then
			RapaxAlarm_SendUpdate("RAID");
		end
		RapaxAlarm.RaidMembers = RaidMembers;		
		return;
	end
	if (event == "UNIT_INVENTORY_CHANGED") then
		local msgUnit = ...;
		if (UnitIsUnit(msgUnit, "PLAYER")) then
			RapaxAlarm.TankMode = RapaxAlarm_CheckTankMode();
		end
	end
	if (event == "UPDATE_SHAPESHIFT_FORM") then
		RapaxAlarm.TankMode = RapaxAlarm_CheckTankMode();
	end
end

function RapaxAlarm_Command(arg1)
	local Command = string.upper(arg1);
	local DescriptionOffset = string.find(arg1,"%s",1);
	local Description = nil;
	
	if (DescriptionOffset) then
		Command = string.upper(string.sub(arg1, 1, DescriptionOffset - 1));
		Description = tostring(string.sub(arg1, DescriptionOffset + 1));
	end
	
	RapaxAlarm_DebugPrint("Command executed: "..Command);
	
end

function RapaxAlarm_OnLoad()
	RapaxAlarmFrame:RegisterEvent("VARIABLES_LOADED");
	RapaxAlarmFrame:RegisterEvent("PARTY_MEMBERS_CHANGED");
	RapaxAlarmFrame:RegisterEvent("RAID_ROSTER_UPDATE");
	RapaxAlarmFrame:RegisterEvent("CHAT_MSG_ADDON");
end

function RapaxAlarm_PlaySound(iSound)
	if (iSound == 0) then
		return;
	end
	
	local currentTime = GetTime();
	local soundTable = { };
	if (RapaxAlarm.IgnoreTime) then
		if (currentTime < RapaxAlarm.IgnoreTime) then
			return;
		end
	end
	RapaxAlarm.IgnoreTime = currentTime + RapaxAlarm.IgnoreTimeAmount;

	local version, build, date, tocversion = GetBuildInfo();

	if (RapaxAlarm.Volume == 2) then
		if (tocversion == 20400) then
			soundTable = {
				"Interface\\AddOns\\RapaxAlarm\\Sounds\\alarmbuzzer_soft.mp3",
				"Interface\\AddOns\\RapaxAlarm\\Sounds\\alarmbeep_soft.mp3",
				"Interface\\AddOns\\RapaxAlarm\\Sounds\\alarmdouble_soft.mp3",
			};
		else
			soundTable = {
				"Interface\\AddOns\\RapaxAlarm\\Sounds\\alarmbuzzer_soft.wav",
				"Interface\\AddOns\\RapaxAlarm\\Sounds\\alarmbeep_soft.wav",
				"Interface\\AddOns\\RapaxAlarm\\Sounds\\alarmdouble_soft.wav",
			};
		end
	elseif (RapaxAlarm.Volume == 1) then
		if (tocversion == 20400) then
			soundTable = {
				"Interface\\AddOns\\RapaxAlarm\\Sounds\\alarmbuzzer_quiet.mp3",
				"Interface\\AddOns\\RapaxAlarm\\Sounds\\alarmbeep_quiet.mp3",
				"Interface\\AddOns\\RapaxAlarm\\Sounds\\alarmdouble_quiet.mp3",
			};
		else
			soundTable = {
				"Interface\\AddOns\\RapaxAlarm\\Sounds\\alarmbuzzer_quiet.wav",
				"Interface\\AddOns\\RapaxAlarm\\Sounds\\alarmbeep_quiet.wav",
				"Interface\\AddOns\\RapaxAlarm\\Sounds\\alarmdouble_quiet.wav",
			};
		end
	elseif (RapaxAlarm.Volume == 4) then
		if (tocversion == 20400) then
			soundTable = {
				"Interface\\AddOns\\RapaxAlarm\\Sounds\\alarmbuzzer_loud.mp3",
				"Interface\\AddOns\\RapaxAlarm\\Sounds\\alarmbeep_loud.mp3",
				"Interface\\AddOns\\RapaxAlarm\\Sounds\\alarmdouble_loud.mp3",
			};
		else
			soundTable = {
				"Interface\\AddOns\\RapaxAlarm\\Sounds\\alarmbuzzer_loud.wav",
				"Interface\\AddOns\\RapaxAlarm\\Sounds\\alarmbeep_loud.wav",
				"Interface\\AddOns\\RapaxAlarm\\Sounds\\alarmdouble_loud.wav",
			};
		end
	else	
		if (tocversion == 2400) then
			soundTable = {
				"Interface\\AddOns\\RapaxAlarm\\Sounds\\alarmbuzzer.mp3",
				"Interface\\AddOns\\RapaxAlarm\\Sounds\\alarmbeep.mp3",
				"Interface\\AddOns\\RapaxAlarm\\Sounds\\alarmdouble.mp3",
			};
		else
			soundTable = {
				"Interface\\AddOns\\RapaxAlarm\\Sounds\\alarmbuzzer.wav",
				"Interface\\AddOns\\RapaxAlarm\\Sounds\\alarmbeep.wav",
				"Interface\\AddOns\\RapaxAlarm\\Sounds\\alarmdouble.wav",
			};
		end
	end
	if (RapaxAlarmData.Sounds[iSound]) then
		PlaySoundFile(soundTable[iSound]);
	end
	if (RapaxAlarm.PowerAuras) then
		RapaxAlarm_DisplayAura(iSound);
	end
end

function RapaxAlarm_RenderOptions()
	local ConfigurationPanel = CreateFrame("FRAME","RapaxAlarm_MainFrame");
	ConfigurationPanel.name = "RapaxAlarm";
	InterfaceOptions_AddCategory(ConfigurationPanel);

	local VolumeText = ConfigurationPanel:CreateFontString("RapaxAlarm_VolumeText","ARTWORK","GameFontNormal");
	VolumeText:SetPoint("TOPLEFT", 170, -145);
	VolumeText:SetText("");

	local EnabledButton = CreateFrame("CheckButton", "RapaxAlarm_EnabledButton", ConfigurationPanel, "ChatConfigCheckButtonTemplate");
	EnabledButton:SetPoint("TOPLEFT", 10, -15)
	EnabledButton.tooltip = RapaxAlarmLocal.UI_EnabledDescription;
	getglobal(EnabledButton:GetName().."Text"):SetText(RapaxAlarmLocal.UI_Enabled);

	local HighSoundButton = CreateFrame("CheckButton", "RapaxAlarm_HighSoundButton", ConfigurationPanel, "ChatConfigCheckButtonTemplate");
	HighSoundButton:SetPoint("TOPLEFT", 10, -45)
	HighSoundButton.tooltip = RapaxAlarmLocal.UI_HighDamageDescription;
	getglobal(HighSoundButton:GetName().."Text"):SetText(RapaxAlarmLocal.UI_HighDamage);

	local LowSoundButton = CreateFrame("CheckButton", "RapaxAlarm_LowSoundButton", ConfigurationPanel, "ChatConfigCheckButtonTemplate");
	LowSoundButton:SetPoint("TOPLEFT", 10, -75)
	LowSoundButton.tooltip = RapaxAlarmLocal.UI_LowDamageDescription;
	getglobal(LowSoundButton:GetName().."Text"):SetText(RapaxAlarmLocal.UI_LowDamage);

	local FailSoundButton = CreateFrame("CheckButton", "RapaxAlarm_FailSoundButton", ConfigurationPanel, "ChatConfigCheckButtonTemplate");
	FailSoundButton:SetPoint("TOPLEFT", 10, -105)
	FailSoundButton.tooltip = RapaxAlarmLocal.UI_FailDescription;
	getglobal(FailSoundButton:GetName().."Text"):SetText(RapaxAlarmLocal.UI_Fail);

	local HighTestButton = CreateFrame("Button", "RapaxAlarm_HighTestButton", ConfigurationPanel, "OptionsButtonTemplate");
	HighTestButton:SetPoint("TOPLEFT", 300, -45);
	HighTestButton.tooltip = RapaxAlarmLocal.UI_TestDescription;
	HighTestButton:SetScript("OnClick",RapaxAlarm_Option_HighTest);
	getglobal(HighTestButton:GetName().."Text"):SetText(RapaxAlarmLocal.UI_Test);

	local LowTestButton = CreateFrame("Button", "RapaxAlarm_LowTestButton", ConfigurationPanel, "OptionsButtonTemplate");
	LowTestButton:SetPoint("TOPLEFT", 300, -75);
	LowTestButton.tooltip = RapaxAlarmLocal.UI_TestDescription;
	LowTestButton:SetScript("OnClick",RapaxAlarm_Option_LowTest);
	getglobal(LowTestButton:GetName().."Text"):SetText(RapaxAlarmLocal.UI_Test);

	local FailTestButton = CreateFrame("Button", "RapaxAlarm_FailTestButton", ConfigurationPanel, "OptionsButtonTemplate");
	FailTestButton:SetPoint("TOPLEFT", 300, -105);
	FailTestButton.tooltip = RapaxAlarmLocal.UI_TestDescription;
	FailTestButton:SetScript("OnClick",RapaxAlarm_Option_FailTest);
	getglobal(FailTestButton:GetName().."Text"):SetText(RapaxAlarmLocal.UI_Test);

	local VolumeSlider = CreateFrame("Slider", "RapaxAlarm_VolumeSlider", ConfigurationPanel, "OptionsSliderTemplate");
	VolumeSlider:SetPoint("TOPLEFT", 12, -145);
	VolumeSlider.tooltip = RapaxAlarmLocal.UI_VolumeDescription;
	VolumeSlider:SetScript("OnValueChanged",RapaxAlarm_Option_SetVolume);
	getglobal(RapaxAlarm_VolumeSlider:GetName().."Text"):SetText(RapaxAlarmLocal.UI_Volume);
	getglobal(RapaxAlarm_VolumeSlider:GetName().."High"):SetText(RapaxAlarmLocal.UI_VolumeMax);
	getglobal(RapaxAlarm_VolumeSlider:GetName().."Low"):SetText(RapaxAlarmLocal.UI_VolumeMin);
	VolumeSlider:SetMinMaxValues(1,4);
	VolumeSlider:SetValueStep(1);
	VolumeSlider:SetValue(RapaxAlarmData.Volume);
	
	RapaxAlarm_Option_SetVolumeText(RapaxAlarmData.Volume);
	
	local TankButton = CreateFrame("CheckButton", "RapaxAlarm_TankButton", ConfigurationPanel, "ChatConfigCheckButtonTemplate");
	TankButton:SetPoint("TOPLEFT", 10, -175)
	TankButton.tooltip = RapaxAlarmLocal.UI_TankDescription;
	getglobal(TankButton:GetName().."Text"):SetText(RapaxAlarmLocal.UI_Tank);

	local DbgButton = CreateFrame("Button", "RapaxAlarm_DbgButton", ConfigurationPanel, "OptionsButtonTemplate");
	DbgButton:SetPoint("BOTTOMRIGHT", 10, 10)
	DbgButton.tooltip = "Print options";
	DbgButton:SetScript("OnClick",RapaxAlarm_Option_Print);
	getglobal(DbgButton:GetName().."Text"):SetText("Print options");


	ConfigurationPanel.okay = 
		function (self)
			RapaxAlarm_Option_Active(EnabledButton:GetChecked());
			RapaxAlarm_Option_Tank(TankButton:GetChecked());
			RapaxAlarm_Option_HighSound(HighSoundButton:GetChecked());
			RapaxAlarm_Option_LowSound(LowSoundButton:GetChecked());
			RapaxAlarm_Option_FailSound(HighSoundButton:GetChecked());
			RapaxAlarmData.Volume = RapaxAlarm.Volume;
			VolumeSlider:SetValue(RapaxAlarm.Volume);
			RapaxAlarm_Option_SetVolumeText(RapaxAlarm.Volume);
		end
	ConfigurationPanel.cancel = 
		function (self)
			EnabledButton:SetChecked(RapaxAlarmData.Active);
			TankButton:SetChecked(RapaxAlarmData.TankMode);
			HighSoundButton:SetChecked(RapaxAlarmData.Sounds[1]);
			LowSoundButton:SetChecked(RapaxAlarmData.Sounds[2]);
			FailSoundButton:SetChecked(RapaxAlarmData.Sounds[3]);
			RapaxAlarm.Volume = RapaxAlarmData.Volume;
			VolumeSlider:SetValue(RapaxAlarm.Volume);
			RapaxAlarm_Option_SetVolumeText(RapaxAlarm.Volume);
		end
	ConfigurationPanel.default = 
		function (self)
			RapaxAlarm_Option_Active(true);
			RapaxAlarm_Option_Tank(false);
			RapaxAlarm_Option_HighSound(true);
			RapaxAlarm_Option_LowSound(true);
			RapaxAlarm_Option_FailSound(true);
			RapaxAlarm.Volume = 3;
			VolumeSlider:SetValue(RapaxAlarm.Volume);
			RapaxAlarm_Option_SetVolumeText(RapaxAlarm.Volume);
		end
end

function RapaxAlarm_ActivateMod()
	if (RapaxAlarmData.Active) then
		RapaxAlarmFrame:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED");
	else
		RapaxAlarmFrame:UnregisterEvent("COMBAT_LOG_EVENT_UNFILTERED");
	end	
end

function RapaxAlarm_Option_Active(state)
	RapaxAlarmData.Active = state;
	getglobal("RapaxAlarm_EnabledButton"):SetChecked(state);
	RapaxAlarm_ActivateMod();
end

function RapaxAlarm_Option_Tank(state)
	RapaxAlarmData.TankMode = state;
	getglobal("RapaxAlarm_TankButton"):SetChecked(state);
	if (state) then
		RapaxAlarm_ChatPrint("Tank mode activated");
	end
end

function RapaxAlarm_Option_ScanMode(state)
	RapaxAlarmData.ScanMode = state;
end

function RapaxAlarm_Command_Help()
	DEFAULT_CHAT_FRAME:AddMessage("[RapaxAlarm] "..string.format(RapaxAlarmLocal.Help_Intro, RapaxAlarm.Version), 0.25, 1.0, 0.25);
	if not (RapaxAlarmData.Active) then
		DEFAULT_CHAT_FRAME:AddMessage(RapaxAlarmLocal.Help_Suspended, 1.0, 0.1, 0.1);		
	end
	DEFAULT_CHAT_FRAME:AddMessage("|cFFEEEE00/RapaxAlarm options|r -- "..RapaxAlarmLocal.Help_Options, 0.25, 1.0, 0.75);
	DEFAULT_CHAT_FRAME:AddMessage("|cFFEEEE00/RapaxAlarm standby|r -- "..RapaxAlarmLocal.Help_Suspend, 0.25, 1.0, 0.75);
	DEFAULT_CHAT_FRAME:AddMessage("|cFFEEEE00/RapaxAlarm version|r -- "..RapaxAlarmLocal.Help_Version, 0.25, 1.0, 0.75);
	DEFAULT_CHAT_FRAME:AddMessage("|cFFEEEE00/RapaxAlarm test|r -- "..RapaxAlarmLocal.Help_TestHigh, 0.25, 1.0, 0.75);
	DEFAULT_CHAT_FRAME:AddMessage("|cFFEEEE00/RapaxAlarm test2|r -- "..RapaxAlarmLocal.Help_TestLow, 0.25, 1.0, 0.75);
	DEFAULT_CHAT_FRAME:AddMessage("|cFFEEEE00/RapaxAlarm test3|r -- "..RapaxAlarmLocal.Help_TestFail, 0.25, 1.0, 0.75);
end

function RapaxAlarm_Option_HighSound(state)
	RapaxAlarmData.Sounds[1] = state;
	getglobal("RapaxAlarm_HighSoundButton"):SetChecked(state);
end

function RapaxAlarm_Option_LowSound(state)
	RapaxAlarmData.Sounds[2] = state;
	getglobal("RapaxAlarm_LowSoundButton"):SetChecked(state);
end

function RapaxAlarm_Option_FailSound(state)
	RapaxAlarmData.Sounds[3] = state;
	getglobal("RapaxAlarm_FailSoundButton"):SetChecked(state);
end

function RapaxAlarm_Option_HighTest()
	RapaxAlarm_PlaySound(1);
end

function RapaxAlarm_Option_LowTest()
	RapaxAlarm_PlaySound(2);
end

function RapaxAlarm_Option_FailTest()
	RapaxAlarm_PlaySound(3);
end

function RapaxAlarm_Option_Print()
	DEFAULT_CHAT_FRAME:AddMessage("|cFFEEEE00[RapaxAlarm] tank|r -- "..RapaxAlarmData.TankMode, 0.25, 1.0, 0.75);
end

function RapaxAlarm_Command_Version()
	RapaxAlarm_SendUpdateRequest();
	local raidmembers = GetNumRaidMembers();
	local partymembers = GetNumPartyMembers();
	local users = 0;

	if (raidmembers > 0 or partymembers > 0) then
		if (raidmembers > 0) then
			for i = 1, raidmembers, 1 do
				local name = UnitName("raid"..i);
				if (RapaxAlarm.Users[name]) then
					RapaxAlarm_ChatPrint(name..": "..RapaxAlarm_ParseVersionColor(RapaxAlarm.Users[name]));
					users = users + 1;
				else
					RapaxAlarm_ChatPrint(name..": |cFF999999"..RapaxAlarmLocal.Group_None.."|r");
				end
			end
			RapaxAlarm_ChatPrint(string.format(RapaxAlarmLocal.Group_RaidMembers, users, raidmembers));
		elseif (partymembers > 0) then
			RapaxAlarm_ChatPrint(UnitName("player")..": "..RapaxAlarm_ParseVersionColor(RapaxAlarm.VersionNumber));
			users = 1;
			for i = 1, partymembers, 1 do
				local name = UnitName("party"..i);
				if (RapaxAlarm.Users[name]) then
					RapaxAlarm_ChatPrint(name..": "..RapaxAlarm_ParseVersionColor(RapaxAlarm.Users[name]));
					users = users + 1;
				else
					RapaxAlarm_ChatPrint(name..": |cFF999999"..RapaxAlarmLocal.Group_None.."|r");
				end
			end
			RapaxAlarm_ChatPrint(string.format(RapaxAlarmLocal.Group_PartyMembers, users, (partymembers + 1)));
		end
	else
		RapaxAlarm_ErrorPrint(RapaxAlarmLocal.Group_NotInGroup);
	end		
end

function RapaxAlarm_ParseVersionColor(iVersionNumber)
	local Color = "";
	if (RapaxAlarm.VersionNumber < iVersionNumber * 1) then
		Color = "|cFFFFFF00"
	elseif (RapaxAlarm.VersionNumber == iVersionNumber * 1) then
		Color = "|cFFFFFFFF"
	else
		Color = "|cFFAAAAAA"
	end
	return Color..RapaxAlarm_ParseVersionNumber(iVersionNumber).."|r"
end

function RapaxAlarm_ParseVersionNumber(iVersionNumber)
	local sVersion = "";
	local iMajor = math.floor(iVersionNumber * 0.0001);
	local iMinor = math.floor((iVersionNumber - (iMajor * 10000)) * 0.01)
	local iMinor2 = iVersionNumber - (iMajor * 10000) - (iMinor * 100)
	if (iMinor2 > 0) then
		sVersion = iMajor.."."..iMinor.."."..iMinor2
	else
		sVersion = iMajor.."."..iMinor
	end
	return sVersion;
end

function RapaxAlarm_SendUpdate(sMethod)
	if not (sMethod == "PARTY" or sMethod == "RAID" or sMethod == "BATTLEGROUND") then
		return;
	end
	local currentTime = GetTime();
	if (RapaxAlarm.IgnoreUpdateTime) then
		if (currentTime < RapaxAlarm.IgnoreUpdateTime) then
			return;
		end
	end
	RapaxAlarm.IgnoreUpdateTime = currentTime + RapaxAlarm.IgnoreUpdateTimeAmount;

	SendAddonMessage("RapaxAlarm_v",RapaxAlarm.VersionNumber,sMethod)
end

function RapaxAlarm_SendUpdateRequest()
	local currentTime = GetTime();
	if (RapaxAlarm.IgnoreUpdateRequestTime) then
		if (currentTime < RapaxAlarm.IgnoreUpdateRequestTime) then
			return;
		end
	end
	RapaxAlarm.IgnoreUpdateRequestTime = currentTime + RapaxAlarm.IgnoreUpdateRequestTimeAmount;

	local raidmembers = GetNumRaidMembers();
	local partymembers = GetNumPartyMembers();
	
	if (UnitInBattleground("player")) then
		SendAddonMessage("RapaxAlarm_u","U","BATTLEGROUND");
	elseif (raidmembers > 0) then
		SendAddonMessage("RapaxAlarm_u","U","RAID");
	elseif (partymembers > 0) then
		SendAddonMessage("RapaxAlarm_u","U","PARTY");
	end
end

function RapaxAlarm_Command_Options()
	InterfaceOptionsFrame_OpenToCategory("RapaxAlarm")
end

function RapaxAlarm_Option_SetVolume()
	RapaxAlarm.Volume = getglobal("RapaxAlarm_VolumeSlider"):GetValue() * 1;
	RapaxAlarm_Option_SetVolumeText(RapaxAlarm.Volume)
end

function RapaxAlarm_Option_SetVolumeText(iVolume)
	if (iVolume == 1) then
		getglobal("RapaxAlarm_VolumeText"):SetText(RapaxAlarmLocal.UI_VolumeQuiet);
	elseif (iVolume == 2) then
		getglobal("RapaxAlarm_VolumeText"):SetText(RapaxAlarmLocal.UI_VolumeSoft);
	elseif (iVolume == 4) then
		getglobal("RapaxAlarm_VolumeText"):SetText(RapaxAlarmLocal.UI_VolumeLoud);
	else
		getglobal("RapaxAlarm_VolumeText"):SetText(RapaxAlarmLocal.UI_VolumeNormal);
	end
end