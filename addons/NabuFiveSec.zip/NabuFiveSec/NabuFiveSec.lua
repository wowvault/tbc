NabuFiveSec = AceLibrary("AceAddon-2.0"):new("AceEvent-2.0", "AceConsole-2.0", "AceDB-2.0", "AceDebug-2.0", "CandyBar-2.0")

local surface = AceLibrary("Surface-1.0")
local nabuBarName = "NabuFiveSecBar"
local nabuBarIcon = "Interface\\Addons\\NabuFiveSec\\textures\\5.tga"

local nabuBarDefaultX = -1
local nabuBarDefaultY = -1
local nabuBarDefaultWidth = 200
local nabuBarDefaultHeight = 18

local nabuBarWFActive = 1


-----------------------------
-- OnInitialize / OnEnable --
-----------------------------

function NabuFiveSec:OnInitialize()
	surface:Register('Smooth', 'Interface\\Addons\\NabuFiveSec\\Textures\\smooth')

	self:RegisterDB("NabuFiveSecDB")
	self:RegisterDefaults("profile", {
		locked = false,
		anchor = {
			x = nabuBarDefaultX,
			y = nabuBarDefaultY,
		},
		size = {
			width = nabuBarDefaultWidth,
			height = nabuBarDefaultHeight,
		},
		icon = true,
		texture = "Smooth",
		currMana = 0,
	})
	
	self.options = {
		type = "group",
		args = {
			lock = {
				name = "Lock",
				desc = "Lock the FiveSec Bar",
				type = "toggle",
				get = function() return self.db.profile.locked end,
				set = "toggleFSBLock",
				map = {[false] = "Unlocked", [true] = "Locked"},
			},
			size = {
				name = "Size",
				desc = "Size of the FiveSec Bar",
				type = "group",
				args = {
					width = {
						name = "Width",
						desc = "Set the width of the FiveSec Bar",
						type = "text",
						usage = "<number>",
						get = function() return self.db.profile.size.width end,
						set = "setFSBWidth",
						validate = "numberValidation",
					},
					heigth = {
						name = "Height",
						desc = "Set the height of the FiveSec Bar",
						type = "text",
						usage = "<number>",
						get = function() return self.db.profile.size.height end,
						set = "setFSBHeight",
						validate = "numberValidation",
					},
				},
			},
			texture = {
				type = "text",
				name = "Texture",
				desc = "Set the texture of the bar.",
				get  = function() return self.db.profile.texture end,
				set  = function(v)
					self.db.profile.texture = v
					self:SetCandyBarTexture(nabuBarName, surface:Fetch(v))
				end,
				validate = surface:List(),
			},
			icon = {
				type = "toggle",
				name = "Icon",
				desc = "Show icon on the bar.",
				get  = function() return self.db.profile.icon end,
				set  = function(v)
					self.db.profile.icon = v
					self:SetCandyBarIcon(nabuBarName, v and nabuBarIcon or nil)
				end,
			},
			reset = {
				name = "Reset",
				desc = "Resets the FiveSec Bar back to the middle of the screen.",
				type = "execute",
				func = "resetFSB",
			}
		}
	}
	
	self:RegisterChatCommand({ "/nfs", "/nfivesec", "/nabufivesec", "/fs", "/fivesec" }, self.options )
end
		

function NabuFiveSec:OnEnable()
	self:CreateAnchorFrame()

	self:RegisterEvent("UNIT_SPELLCAST_SUCCEEDED")
	self:RegisterEvent('Surface_SetGlobal', function()
		self:SetCandyBarTexture(nabuBarName, surface:Fetch(self.db.profile.texture))
	end)
	
	self:Debug("OnEnable.Processed")
end


----------------------
-- Option Functions --
----------------------

function NabuFiveSec:toggleFSBLock(v)
	self.db.profile.locked = v
	self:SetAnchorStyle(v)
end


function NabuFiveSec:setFSBWidth(v)
	self.db.profile.size.width = tonumber(v)
	self:UpdateSize()
end


function NabuFiveSec:setFSBHeight(v)
	self.db.profile.size.height = tonumber(v)
	self:UpdateSize()
end


function NabuFiveSec:resetFSB()
	self.db.profile.anchor.x = nabuBarDefaultX
	self.db.profile.anchor.y = nabuBarDefaultY 
	self.db.profile.size.width = nabuBarDefaultWidth
	self.db.profile.size.height = nabuBarDefaultHeight
	
	self:LoadAnchorPosition()
	self:UpdateSize()
end


function NabuFiveSec:numberValidation(v)
	return tonumber(v) ~= nil
end


-----------------------
-- General Functions --
-----------------------

function NabuFiveSec:UpdateSize()
	self.AnchorFrame:SetWidth(self.db.profile.size.width + self.db.profile.size.height)
	self.AnchorFrame:SetHeight(self.db.profile.size.height)
	self:SetCandyBarWidth(nabuBarName, self.db.profile.size.width)
	self:SetCandyBarHeight(nabuBarName, self.db.profile.size.height)
	
	self:Debug("UpdateSize.Processed")
end


----------------------------
-- Anchor Frame Functions --
----------------------------

function NabuFiveSec:CreateAnchorFrame()
	self.AnchorFrame = CreateFrame("Frame","NabuFiveSecAnchor",UIParent)
	self.AnchorFrame:SetWidth(self.db.profile.size.width + self.db.profile.size.height)
	self.AnchorFrame:SetHeight(self.db.profile.size.height)
	self.AnchorFrame:SetFrameStrata("BACKGROUND")
	self.AnchorFrame:SetClampedToScreen(true)
	
	self.AnchorFrame:SetScript("OnMouseDown",	function() 
													if not self.db.profile.locked then 
														this:StartMoving() 
													end 
												end )

	self.AnchorFrame:SetScript("OnMouseUp",	function()
												this:StopMovingOrSizing()
												if not self.db.profile.locked then
													self:SaveAnchorPosition()
												end
											end )
											
	local gameFont, _, _ = GameFontHighlightSmall:GetFont()										
	self.AnchorFrame.Range = self.AnchorFrame:CreateFontString("AnchorBarName", "OVERLAY")
	self.AnchorFrame.Range:SetJustifyH("CENTER")
	self.AnchorFrame.Range:SetFont(gameFont, 12)
	self.AnchorFrame.Range:SetTextColor(1, 1, 1)
	self.AnchorFrame.Range:SetText("WF Totem Bar")
	self.AnchorFrame.Range:ClearAllPoints()
	self.AnchorFrame.Range:SetPoint("BOTTOM", self.AnchorFrame, "TOP", 0, 2)
							
	self:LoadAnchorPosition()
	self:SetAnchorStyle(self.db.profile.locked)
	self:CreateCandyBar()
	
	self.AnchorFrame:Show()
end


function NabuFiveSec:SaveAnchorPosition()
	self.db.profile.anchor.x = floor(this:GetLeft() * self.AnchorFrame:GetEffectiveScale() + .5)
	self.db.profile.anchor.y = floor(this:GetTop() * self.AnchorFrame:GetEffectiveScale() + .5)
	
	self:Debug("SaveAnchorPosition: x=", self.db.profile.anchor.x, ", y=", self.db.profile.anchor.y)
end


function NabuFiveSec:LoadAnchorPosition()
	self.AnchorFrame:ClearAllPoints()
	if self.db.profile.anchor.x > -1 then
		local s = self.AnchorFrame:GetEffectiveScale()
		self.AnchorFrame:SetPoint("TOPLEFT", UIParent, "BOTTOMLEFT", floor(self.db.profile.anchor.x/s + .5), floor(self.db.profile.anchor.y/s + .5))
	else
		self.AnchorFrame:SetPoint("CENTER", UIParent, "CENTER")
	end
	
	self:Debug(
		"LoadAnchorPosition: x=", floor(self.db.profile.anchor.x/self.AnchorFrame:GetEffectiveScale() + .5),
		", y=", floor(self.db.profile.anchor.y/self.AnchorFrame:GetEffectiveScale() + .5),
		", width=", (self.db.profile.size.width),
		", height=", (self.db.profile.size.height)
	)
end


function NabuFiveSec:SetAnchorStyle(locked)
	if locked then
		self.AnchorFrame:EnableMouse(false)
		self.AnchorFrame:SetMovable(false)
		
		self.AnchorFrame:SetBackdrop(nil)
		self.AnchorFrame:SetBackdropBorderColor(nil)
		self.AnchorFrame:SetBackdropColor(nil)
		
		self.AnchorFrame.Range:Hide()
	else
		self.AnchorFrame:EnableMouse(true)
		self.AnchorFrame:SetMovable(true)
		
		self.AnchorFrame:SetBackdrop({
			bgFile = "Interface\\Tooltips\\UI-Tooltip-Background", tile = true, tileSize = 8,
		})
		self.AnchorFrame:SetBackdropBorderColor(TOOLTIP_DEFAULT_COLOR.r, TOOLTIP_DEFAULT_COLOR.g, TOOLTIP_DEFAULT_COLOR.b)
		self.AnchorFrame:SetBackdropColor(TOOLTIP_DEFAULT_BACKGROUND_COLOR.r, TOOLTIP_DEFAULT_BACKGROUND_COLOR.g, TOOLTIP_DEFAULT_BACKGROUND_COLOR.b)
		
		self.AnchorFrame.Range:Show()
	end
end


---------------------------
-- FiveSec Bar Functions --
---------------------------

function NabuFiveSec:CreateCandyBar()	
	self:RegisterCandyBar(nabuBarName, 10, "WFT", nil, "blue")
	self:SetCandyBarTexture(nabuBarName, surface:Fetch(self.db.profile.texture))
	self:SetCandyBarPoint(nabuBarName, "CENTER", self.AnchorFrame, "CENTER")
	self:SetCandyBarFade(nabuBarName, 1)
	self:SetCandyBarWidth(nabuBarName, self.db.profile.size.width)
	self:SetCandyBarHeight(nabuBarName, self.db.profile.size.height)
	
	self:Debug("CreateCandyBar.Processed")
end

function NabuFiveSecIntUpdate()
	NabuFiveSec:UpdateWF()
end

function NabuFiveSec:UpdateWF()
--	SendChatMessage("nfs:updatewf")
	if self:IsCandyBarRegistered(nabuBarName) then
		self:StartCandyBar(nabuBarName, false)
		self:SetCandyBarColor(nabuBarName, "blue", 0.4)
		if ( nabuBarWFActive == 1 ) then
			NabuFiveSec:ScheduleEvent(NabuFiveSecIntUpdate, 5)
		end
	end
end

--	if self:IsCandyBarRegistered(nabuBarName) then
--		self:ScheduleEvent(NabuFiveSec:UNIT_SPELLCAST_SUCCEEDED("player", "Windfury Totem"), 5)
--	end

function NabuFiveSec:UNIT_SPELLCAST_SUCCEEDED(msg1, msg2)
	if ( msg1 == "player") then
		if ( msg2 == "Windfury Totem" ) then
			nabuBarWFActive = 1
			NabuFiveSecIntUpdate()
		elseif ( msg2 == "Grace of Air Totem" ) then
			NabuFiveSec:CancelAllScheduledEvents()
			nabuBarWFActive = 0
			if self:IsCandyBarRegistered(nabuBarName) then
				self:SetCandyBarColor(nabuBarName, "green", 0.4) 
			end
		end
	end
end